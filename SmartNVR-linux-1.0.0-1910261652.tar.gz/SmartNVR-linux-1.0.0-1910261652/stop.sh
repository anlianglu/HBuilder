#!/bin/bash
CWD=$(cd "$(dirname $0)";pwd)
"$CWD"/smartnvr stop
"$CWD"/smartnvr uninstall 