#!/bin/bash
CWD=$(cd "$(dirname $0)";pwd)
"$CWD"/smartnvr install
"$CWD"/smartnvr start 